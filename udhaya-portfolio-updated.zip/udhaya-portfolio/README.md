# Personal Amazon & E-commerce Portfolio

A responsive static portfolio website using a warm ivory, sage and muted olive palette. The animated avatar GIF is used in the hero section and the supplied portrait photo appears in the About section.

## Before publishing
1. Replace every `Your Name` label in `index.html` with the name you want clients to see.
2. Replace `your-email@example.com` in `index.html` with your professional email address.
3. Review the About copy and only keep skills/services you are ready to deliver.
4. Keep the lunch-box project marked as a fictional practice sample until you have genuine client work.

## Preview locally
Open `index.html` in a browser. Keep the `assets` folder beside it so the avatar and profile photo load.

## Deploy with GitHub + Vercel
1. Create a new GitHub repository and upload `index.html`, `styles.css`, `script.js`, and the `assets` folder.
2. Sign in to Vercel using GitHub and choose **Add New → Project**.
3. Import your repository. This is a static HTML site; no framework or build command is required.
4. Deploy and open the Vercel URL to check desktop and mobile layouts.
